###### Assignment07 - Python Exception Handling and Pickling
###### Dev: Rachel Smith
###### Date: 08/25/2019
###### Basic Math Program will take user inputs and make computations on them

import pickle
import os

# Defining Functions or Classes

class Error(Exception):
    """Base class for other exceptions"""
    pass
class ValueNotInList(Error):
    """Raised when the input value is not in the list"""
    pass

def get_inputs():
    while True:
        try:
            user_number = float(input('Please enter a number: '))
            break
        except ValueError:
            print("Oops! That wasn't a number, please try again.")
    return user_number


def get_menu_choice():
    print('''
    You have the following choices for math operations:
         1 - Add
         2 - Subtract
         3 - Multiply
         4 - Divide
    ''')
    while True:
        try:
            choice = int(input('Please enter which mathematical operation you would like to do: '))
            if choice not in range(1,5):
                raise ValueNotInList
            break
        except ValueError:
            print('Please enter a number between 1 and 4.')
        except ValueNotInList:
            print('Please enter a number between 1 and 4.')
    return choice


def do_math(a, b, func):
    if func == 1:
        try:
            c = a + b
            return c
        except:
            print('An error occurred.')
    elif func == 2:
        try:
            c = a - b
            return c
        except:
            print('An error occurred.')
    elif func == 3:
        try:
            c = a * b
            return c
        except:
            print('An error occurred.')
    elif func == 4:
        try:
            c = a / b
            return c
        except:
            print('An error occurred.')
    else:
        print('Some other error occurred.')

# Main

stuff = {}
file = '~save.p'

try:
    with open(file, 'rb') as f:
        stuff = pickle.load(f)
    print('We noticed you have run this program before\n'
           'The last saved values we had on file for you are {} and {}.'.format(stuff['x'], stuff['y']))
    keep = ''
    while keep not in ('y', 'n'):
        keep = input('Would you like to keep those values? [Y/N] ').lower().strip()
        if keep == 'y':
            stuff['z'] = get_menu_choice()
        elif keep == 'n':
            stuff['x'] = get_inputs()
            stuff['y'] = get_inputs()
            stuff['z'] = get_menu_choice()
        else:
            'You did not enter Y or N, please try again.'
except:
    stuff['x'] = get_inputs()
    stuff['y'] = get_inputs()
    stuff['z'] = get_menu_choice()

print('Your answer is: ', do_math(stuff['x'], stuff['y'], stuff['z']))


if not os.path.exists(file):
    open(file, 'w+')
    file.close()

with open("~save.p", "wb") as f:
    pickle.dump(stuff, f)

